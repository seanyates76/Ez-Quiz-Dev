"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// netlify/functions/lib/normalizer.js
var require_normalizer = __commonJS({
  "netlify/functions/lib/normalizer.js"(exports2, module2) {
    "use strict";
    var TYPE_ALIASES = /* @__PURE__ */ new Map([
      ["MULTIPLE_CHOICE", "MC"],
      ["MULTIPLE-CHOICE", "MC"],
      ["MULTIPLECHOICE", "MC"],
      ["MULTIPLE CHOICE", "MC"],
      ["CHOICE", "MC"],
      ["MCQ", "MC"],
      ["TRUE_FALSE", "TF"],
      ["TRUEFALSE", "TF"],
      ["TRUE/FALSE", "TF"],
      ["TRUE FALSE", "TF"],
      ["YES_NO", "YN"],
      ["YESNO", "YN"],
      ["YES/NO", "YN"],
      ["MATCH", "MT"],
      ["MATCHING", "MT"],
      ["PAIR", "MT"],
      ["PAIRING", "MT"],
      ["MATCH_PAIRS", "MT"]
    ]);
    function sanitizeString(value) {
      if (value == null) return "";
      return String(value).trim();
    }
    function normalizeLegacyLines(text, count) {
      if (!text) return { title: "", lines: "" };
      const raw = String(text).split("\n").map((l) => l.trim()).filter(Boolean).map((l) => l.replace(/^\d+\.\s*/, ""));
      let title = "";
      if (raw.length && /^title\s*:/i.test(raw[0])) {
        title = raw.shift().replace(/^title\s*:/i, "").trim();
      }
      const limit = Math.max(1, Math.min(50, count == null ? raw.length : parseInt(count, 10) || raw.length));
      const lines = raw.filter((l) => /^(MC|TF|YN|MT)\|/i.test(l)).slice(0, limit);
      return { title, lines: lines.join("\n") };
    }
    function tryParseJsonLoose(text) {
      if (!text) return null;
      const trimmed = text.trim();
      if (!trimmed) return null;
      const withoutFence = trimmed.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
      const candidates = [trimmed, withoutFence];
      for (const candidate of candidates) {
        try {
          const parsed = JSON.parse(candidate);
          return parsed;
        } catch {
        }
      }
      const firstBrace = trimmed.indexOf("{");
      const firstBracket = trimmed.indexOf("[");
      let start = -1;
      let isArray = false;
      if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
        start = firstBrace;
        isArray = false;
      } else if (firstBracket !== -1) {
        start = firstBracket;
        isArray = true;
      }
      if (start === -1) return null;
      let depth = 0;
      for (let end = start; end < trimmed.length; end++) {
        const ch = trimmed[end];
        if (ch === "{" || ch === "[") {
          depth++;
        } else if (ch === "}" || ch === "]") {
          depth--;
          if (depth === 0) {
            const snippet = trimmed.slice(start, end + 1);
            try {
              const parsed = JSON.parse(snippet);
              if (isArray && Array.isArray(parsed)) return { questions: parsed };
              return parsed;
            } catch {
            }
            break;
          }
        }
      }
      return null;
    }
    function toArray(value) {
      if (value == null) return [];
      if (Array.isArray(value)) return value;
      return [value];
    }
    function letterToIndex(letter) {
      if (typeof letter !== "string") return null;
      const cleaned = letter.trim();
      if (!cleaned) return null;
      const single = cleaned.replace(/[^A-Za-z]/g, "").toUpperCase();
      if (single.length !== 1) return null;
      return single.charCodeAt(0) - 65;
    }
    function optionTextToIndex(text, options) {
      if (typeof text !== "string") return null;
      const cleaned = text.trim().toLowerCase();
      if (!cleaned) return null;
      const idx = options.findIndex((opt) => opt.toLowerCase() === cleaned);
      return idx >= 0 ? idx : null;
    }
    function normalizeCorrectIndexes(raw, options) {
      const values = [];
      if (Array.isArray(raw)) {
        for (const item of raw) {
          values.push(...normalizeCorrectIndexes(item, options));
        }
      } else if (typeof raw === "string") {
        const chunk = raw.split(/[;,]/).map((s) => s.trim()).filter(Boolean);
        if (chunk.length > 1) {
          for (const part of chunk) {
            values.push(...normalizeCorrectIndexes(part, options));
          }
        } else {
          const num = Number(raw);
          if (Number.isInteger(num)) {
            values.push(num >= 1 ? num - 1 : num);
          } else {
            const letterIdx = letterToIndex(raw);
            if (letterIdx != null) {
              values.push(letterIdx);
            } else {
              const byText = optionTextToIndex(raw, options);
              if (byText != null) values.push(byText);
            }
          }
        }
      } else if (typeof raw === "number" && Number.isFinite(raw)) {
        values.push(raw >= 1 ? raw - 1 : raw);
      } else if (raw && typeof raw === "object") {
        if ("index" in raw) {
          values.push(...normalizeCorrectIndexes(raw.index, options));
        }
        if ("letter" in raw) {
          values.push(...normalizeCorrectIndexes(raw.letter, options));
        }
        if ("value" in raw) {
          values.push(...normalizeCorrectIndexes(raw.value, options));
        }
      }
      const uniq = [];
      for (const v of values) {
        const idx = Number.isFinite(v) ? parseInt(v, 10) : NaN;
        if (Number.isInteger(idx) && idx >= 0 && idx < options.length && !uniq.includes(idx)) {
          uniq.push(idx);
        }
      }
      if (uniq.length === 0 && options.length) {
        uniq.push(0);
      }
      return uniq.sort((a, b) => a - b);
    }
    function normalizeBoolean(raw, fallbackTrue) {
      if (typeof raw === "boolean") return raw;
      if (typeof raw === "number") return raw !== 0;
      if (typeof raw === "string") {
        const cleaned = raw.trim().toLowerCase();
        if (["true", "t", "yes", "y", "1"].includes(cleaned)) return true;
        if (["false", "f", "no", "n", "0"].includes(cleaned)) return false;
      }
      return !!fallbackTrue;
    }
    function toZeroBasedIndex(value, size) {
      if (Number.isInteger(value)) {
        if (value === 0) return 0;
        if (value > 0 && value <= size) return value - 1;
        if (value < 0 && Math.abs(value) <= size) return Math.abs(value) - 1;
        return null;
      }
      const parsed = parseInt(value, 10);
      if (Number.isInteger(parsed)) {
        if (parsed === 0) return 0;
        if (parsed > 0 && parsed <= size) return parsed - 1;
        if (parsed < 0 && Math.abs(parsed) <= size) return Math.abs(parsed) - 1;
      }
      return null;
    }
    function normalizeMatches(raw, leftLen, rightLen) {
      const pairs = [];
      const pushPair = (li, ri) => {
        if (!Number.isInteger(li) || !Number.isInteger(ri)) return;
        if (li < 0 || li >= leftLen) return;
        if (ri < 0 || ri >= rightLen) return;
        if (!pairs.some(([a, b]) => a === li && b === ri)) pairs.push([li, ri]);
      };
      if (Array.isArray(raw)) {
        for (const item of raw) {
          if (Array.isArray(item)) {
            if (item.length >= 2) {
              const li = toZeroBasedIndex(item[0], leftLen);
              let ri = toZeroBasedIndex(item[1], rightLen);
              if (ri == null) {
                const letter = letterToIndex(item[1]);
                if (letter != null) ri = letter;
              }
              if (Number.isInteger(li) && Number.isInteger(ri)) pushPair(li, ri);
            }
            continue;
          }
          if (item && typeof item === "object") {
            const liSource = item.left ?? item.source ?? item.question ?? item.prompt;
            const riSource = item.right ?? item.target ?? item.answer ?? item.response ?? item.match;
            const li = toZeroBasedIndex(liSource, leftLen);
            let ri = toZeroBasedIndex(riSource, rightLen);
            if (ri == null) {
              const letter = letterToIndex(riSource);
              if (letter != null) ri = letter;
            }
            if (Number.isInteger(li) && Number.isInteger(ri)) pushPair(li, ri);
            continue;
          }
          if (typeof item === "string") {
            const parts = item.split(/[-:>]/).map((s) => s.trim()).filter(Boolean);
            if (parts.length >= 2) {
              const li = toZeroBasedIndex(parts[0], leftLen);
              let ri = toZeroBasedIndex(parts[1], rightLen);
              if (ri == null) {
                const letter = letterToIndex(parts[1]);
                if (letter != null) ri = letter;
              }
              if (Number.isInteger(li) && Number.isInteger(ri)) pushPair(li, ri);
            }
          }
        }
      } else if (typeof raw === "string") {
        const segments = raw.split(",");
        for (const seg of segments) {
          const parts = seg.split(/[-:>]/).map((s) => s.trim()).filter(Boolean);
          if (parts.length >= 2) {
            const li = toZeroBasedIndex(parts[0], leftLen);
            let ri = toZeroBasedIndex(parts[1], rightLen);
            if (ri == null) {
              const letter = letterToIndex(parts[1]);
              if (letter != null) ri = letter;
            }
            if (Number.isInteger(li) && Number.isInteger(ri)) pushPair(li, ri);
          }
        }
      }
      return pairs;
    }
    function resolveType(rawType) {
      const t = sanitizeString(rawType).toUpperCase();
      if (!t) return "";
      if (["MC", "TF", "YN", "MT"].includes(t)) return t;
      return TYPE_ALIASES.get(t) || "";
    }
    function normalizeStructuredQuestion(raw) {
      if (!raw || typeof raw !== "object") return null;
      const type = resolveType(raw.type ?? raw.kind ?? raw.questionType ?? raw.format);
      if (!type) return null;
      const prompt = sanitizeString(raw.prompt ?? raw.question ?? raw.text ?? raw.stem ?? raw.body);
      if (!prompt) return null;
      if (type === "MC") {
        const options = toArray(raw.options ?? raw.choices ?? raw.answers ?? raw.variants ?? raw.optionsText).map(sanitizeString).filter(Boolean).slice(0, 8);
        if (options.length < 2) return null;
        const correctRaw = raw.correct ?? raw.answer ?? raw.answers ?? raw.correctOptions ?? raw.correctAnswer ?? raw.key;
        const correct = normalizeCorrectIndexes(correctRaw, options);
        return { type: "MC", prompt, options, correct };
      }
      if (type === "TF") {
        const correctRaw = raw.correct ?? raw.answer ?? raw.value ?? raw.solution;
        const correct = normalizeBoolean(correctRaw, true);
        return { type: "TF", prompt, correct };
      }
      if (type === "YN") {
        const correctRaw = raw.correct ?? raw.answer ?? raw.value ?? raw.solution;
        const correct = normalizeBoolean(correctRaw, true);
        return { type: "YN", prompt, correct };
      }
      if (type === "MT") {
        const left = toArray(raw.left ?? raw.columnA ?? raw.prompts ?? raw.source ?? (Array.isArray(raw.pairs) ? raw.pairs.map((p) => p.left) : void 0)).map(sanitizeString).filter(Boolean);
        const right = toArray(raw.right ?? raw.columnB ?? raw.responses ?? raw.target ?? (Array.isArray(raw.pairs) ? raw.pairs.map((p) => p.right) : void 0)).map(sanitizeString).filter(Boolean);
        if (left.length === 0 || right.length === 0) return null;
        const matchesRaw = raw.matches ?? raw.pairs ?? raw.mapping ?? raw.answers ?? raw.correct;
        const matches = normalizeMatches(matchesRaw, left.length, right.length);
        if (matches.length === 0) return null;
        return { type: "MT", prompt, left, right, matches };
      }
      return null;
    }
    var LEGACY_MC_RE = /^MC\|(.*)\|(.+?)\|(.+?)$/i;
    var LEGACY_TF_RE = /^TF\|(.*)\|(T|F)$/i;
    var LEGACY_YN_RE = /^YN\|(.*)\|(Y|N)$/i;
    var LEGACY_MT_RE = /^MT\|(.*)\|(.+?)\|(.+?)\|(.+?)$/i;
    function parseLegacyQuestion(line) {
      const trimmed = sanitizeString(line);
      if (!trimmed) return null;
      if (LEGACY_MC_RE.test(trimmed)) {
        const [, prompt, optsRaw, correctRaw] = trimmed.match(LEGACY_MC_RE);
        const options = optsRaw.split(";").map((s) => sanitizeString(s.replace(/^[A-D]\)\s*/i, ""))).filter(Boolean);
        if (options.length < 2) return null;
        const correct = normalizeCorrectIndexes(correctRaw, options);
        return { type: "MC", prompt: sanitizeString(prompt), options, correct };
      }
      if (LEGACY_TF_RE.test(trimmed)) {
        const [, prompt, value] = trimmed.match(LEGACY_TF_RE);
        return { type: "TF", prompt: sanitizeString(prompt), correct: /^T$/i.test(value) };
      }
      if (LEGACY_YN_RE.test(trimmed)) {
        const [, prompt, value] = trimmed.match(LEGACY_YN_RE);
        return { type: "YN", prompt: sanitizeString(prompt), correct: /^Y$/i.test(value) };
      }
      if (LEGACY_MT_RE.test(trimmed)) {
        const [, prompt, leftRaw, rightRaw, pairsRaw] = trimmed.match(LEGACY_MT_RE);
        const left = leftRaw.split(";").map((s) => sanitizeString(s.replace(/^\d+\)\s*/, ""))).filter(Boolean);
        const right = rightRaw.split(";").map((s) => sanitizeString(s.replace(/^[A-Z]\)\s*/i, ""))).filter(Boolean);
        const matches = normalizeMatches(pairsRaw, left.length, right.length);
        if (left.length && right.length && matches.length) {
          return { type: "MT", prompt: sanitizeString(prompt), left, right, matches };
        }
      }
      return null;
    }
    function quizFromLegacyLines({ title, lines }, { topic = "", allowedTypes, limit }) {
      const questions = [];
      const allowed = allowedTypes instanceof Set && allowedTypes.size ? allowedTypes : null;
      const pieces = String(lines || "").split("\n").map((l) => l.trim()).filter(Boolean);
      for (const piece of pieces) {
        const q = parseLegacyQuestion(piece);
        if (!q) continue;
        if (allowed && !allowed.has(q.type)) continue;
        questions.push(q);
        if (limit && questions.length >= limit) break;
      }
      return {
        title: sanitizeString(title),
        topic: sanitizeString(topic),
        questions
      };
    }
    function normalizeQuizV22(raw, opts = {}) {
      const { topic = "", count, types } = opts;
      const limit = Number.isFinite(count) ? Math.max(1, Math.min(50, parseInt(count, 10))) : void 0;
      const allowed = Array.isArray(types) && types.length ? new Set(types.map((t) => sanitizeString(t).toUpperCase()).filter((t) => /^(MC|TF|YN|MT)$/.test(t))) : null;
      const warnFallback = (reason, source) => {
        try {
          const rendered = typeof source === "string" ? source : JSON.stringify(source);
          const len = rendered ? rendered.length : 0;
          console.warn("[quiz-v2]", { reason, len });
        } catch {
          console.warn("[quiz-v2]", { reason, len: 0 });
        }
      };
      const fallbackFromLegacy = (text, reason) => {
        warnFallback(reason, text);
        const legacy = normalizeLegacyLines(text, limit);
        const quiz = quizFromLegacyLines(legacy, { topic, allowedTypes: allowed, limit });
        if (!quiz.questions.length) {
          throw Object.assign(new Error("No valid quiz lines found"), { code: "NO_QUESTIONS" });
        }
        return quiz;
      };
      let data = raw;
      if (typeof data === "string") {
        const parsed = tryParseJsonLoose(data);
        if (parsed) data = parsed;
        else return fallbackFromLegacy(data, "json-parse-failed");
      }
      if (data && typeof data === "object" && !Array.isArray(data)) {
        if (data.quiz && typeof data.quiz === "object") data = data.quiz;
        else if (data.result && typeof data.result === "object") data = data.result;
        if (Array.isArray(data) && data.length) {
          data = { questions: data };
        }
        const maybeLines = data.lines ?? data.output ?? data.text;
        const questionSource = Array.isArray(data.questions) ? data.questions : Array.isArray(data.items) ? data.items : Array.isArray(data.quizItems) ? data.quizItems : null;
        if (questionSource && questionSource.length) {
          const questions = [];
          for (const rawQ of questionSource) {
            const q = normalizeStructuredQuestion(rawQ);
            if (!q) continue;
            if (allowed && !allowed.has(q.type)) continue;
            questions.push(q);
            if (limit && questions.length >= limit) break;
          }
          if (questions.length) {
            return {
              title: sanitizeString(data.title ?? data.quizTitle ?? data.name ?? ""),
              topic: sanitizeString(data.topic ?? topic),
              questions
            };
          }
        }
        if (typeof maybeLines === "string" && maybeLines.trim()) {
          return fallbackFromLegacy(maybeLines, "legacy-lines-field");
        }
      }
      return fallbackFromLegacy(typeof raw === "string" ? raw : JSON.stringify(raw), "no-structured-questions");
    }
    function quizToLegacyLines2(quiz, opts = {}) {
      const limit = Number.isFinite(opts.count) ? Math.max(1, Math.min(50, parseInt(opts.count, 10))) : void 0;
      if (!quiz || typeof quiz !== "object") return { title: "", lines: "" };
      const lines = [];
      const questions = Array.isArray(quiz.questions) ? quiz.questions : [];
      for (const q of questions) {
        if (q.type === "MC") {
          const options = Array.isArray(q.options) ? q.options : [];
          if (options.length < 2) continue;
          const correct = Array.isArray(q.correct) && q.correct.length ? q.correct : [0];
          const optText = options.map((opt, idx) => `${String.fromCharCode(65 + idx)}) ${sanitizeString(opt)}`).join(";");
          const ans = correct.map((idx) => String.fromCharCode(65 + idx)).join(",");
          lines.push(`MC|${sanitizeString(q.prompt)}|${optText}|${ans}`);
        } else if (q.type === "TF") {
          const ans = q.correct ? "T" : "F";
          lines.push(`TF|${sanitizeString(q.prompt)}|${ans}`);
        } else if (q.type === "YN") {
          const ans = q.correct ? "Y" : "N";
          lines.push(`YN|${sanitizeString(q.prompt)}|${ans}`);
        } else if (q.type === "MT") {
          const left = Array.isArray(q.left) ? q.left : [];
          const right = Array.isArray(q.right) ? q.right : [];
          const matches = Array.isArray(q.matches) ? q.matches : [];
          if (!left.length || !right.length || !matches.length) continue;
          const leftText = left.map((item, idx) => `${idx + 1}) ${sanitizeString(item)}`).join(";");
          const rightText = right.map((item, idx) => `${String.fromCharCode(65 + idx)}) ${sanitizeString(item)}`).join(";");
          const pairText = matches.map(([li, ri]) => `${li + 1}-${String.fromCharCode(65 + ri)}`).join(",");
          lines.push(`MT|${sanitizeString(q.prompt)}|${leftText}|${rightText}|${pairText}`);
        }
        if (limit && lines.length >= limit) break;
      }
      return { title: sanitizeString(quiz.title), lines: lines.join("\n") };
    }
    module2.exports = {
      normalizeLegacyLines,
      normalizeQuizV2: normalizeQuizV22,
      quizToLegacyLines: quizToLegacyLines2
    };
  }
});

// netlify/functions/lib/providers.js
var require_providers = __commonJS({
  "netlify/functions/lib/providers.js"(exports2, module2) {
    "use strict";
    var { normalizeLegacyLines } = require_normalizer();
    function buildPrompt(topic, count, types, difficulty) {
      const allowed = Array.isArray(types) && types.length ? types.map((t) => t.toUpperCase()).filter((t) => /^(MC|TF|YN|MT)$/.test(t)) : ["MC", "TF", "YN", "MT"];
      const allowLine = `Allowed question types: ${allowed.join(", ")} (use only these).`;
      const diff = difficulty && String(difficulty).toLowerCase() || "";
      const prettyDiff = diff ? diff.split(/[-_\s]+/).map((w) => w ? w.charAt(0).toUpperCase() + w.slice(1) : "").join(" ") : "";
      const diffLine = diff ? `Difficulty guidance: scale is Very Easy < Easy < Medium < Hard < Expert. Target level: ${prettyDiff}. Match question complexity, vocabulary, and expected knowledge to this level.` : "";
      return [
        `Task: Produce a quiz about ${topic}.`,
        allowLine,
        diffLine,
        `Output format:`,
        `1) First line must be: TITLE: <Professional Title>`,
        `   - Use Title Case, depluralize the last word if plural (e.g., "Histories" -> "History", "Ports" -> "Port").`,
        `   - No parentheses or file extensions; keep it concise (e.g., "World History Quiz").`,
        `2) Then output EXACTLY ${count} quiz lines, one per line, using ONLY these formats:`,
        `MC|Question?|A) Option 1;B) Option 2;C) Option 3;D) Option 4|A`,
        `MC|Question with multiple answers?|A) 1;B) 2;C) 3;D) 4|A,C`,
        `TF|A true/false statement.|T`,
        `YN|A yes/no question.|Y`,
        `MT|Match.|1) L1;2) L2;3) L3|A) R1;B) R2;C) R3|1-A,2-B,3-C`,
        `Hard rules:`,
        `- Output only plain text. No numbering, bullet points, or commentary.`,
        `- Exactly 1 title line starting with "TITLE:" plus ${count} quiz lines.`,
        `- Use only allowed types: ${allowed.join(", ")}.`,
        `- MC correct field may be single (A) or multiple (A,C).`,
        `- No blank lines.`
      ].join("\n");
    }
    function buildStructuredPrompt2(topic, count, types, difficulty) {
      const allowed = Array.isArray(types) && types.length ? types.map((t) => t.toUpperCase()).filter((t) => /^(MC|TF|YN|MT)$/.test(t)) : ["MC", "TF", "YN", "MT"];
      const diff = difficulty && String(difficulty).toLowerCase() || "";
      const prettyDiff = diff ? diff.split(/[-_\s]+/).map((w) => w ? w.charAt(0).toUpperCase() + w.slice(1) : "").join(" ") : "";
      const diffLine = diff ? `Match difficulty to ${prettyDiff} on a scale of Very Easy < Easy < Medium < Hard < Expert.` : "";
      return [
        `You are generating a structured quiz about ${topic}.`,
        diffLine,
        `Allowed question types: ${allowed.join(", ")}. Use only these codes.`,
        `Respond with valid minified JSON only. Do not include markdown fences or commentary.`,
        `Schema:`,
        `{`,
        `  "title": "Professional title in Title Case",`,
        `  "topic": "Short topic label",`,
        `  "questions": [`,
        `    {`,
        `      "type": "MC" | "TF" | "YN" | "MT",`,
        `      "prompt": "Question text",`,
        `      // MC only: "options": ["Option 1", "Option 2", ...], minimum 2,`,
        `      // MC only: "correct": ["A", "C"], letters for all correct options`,
        `      // TF only: "correct": true|false`,
        `      // YN only: "correct": true|false (true = Yes)`,
        `      // MT only: "left": ["Prompt 1", ...], "right": ["Match A", ...],`,
        `      // MT only: "matches": [[1, "A"], [2, "B"], ...] using 1-based numbers + letters`,
        `    }`,
        `  ]`,
        `}`,
        `Include exactly ${count} questions. Ensure arrays align and answers are accurate.`
      ].filter(Boolean).join("\n");
    }
    function splitNormalizedLines(lines) {
      if (!lines) return [];
      return String(lines).split("\n").map((l) => l.trim()).filter(Boolean);
    }
    function stemKeyFromLine(line) {
      if (!line) return "";
      const raw = String(line).trim();
      if (!raw) return "";
      const parts = raw.split("|");
      const stem = parts.length > 1 ? parts[1] : raw;
      return stem.trim().replace(/\s+/g, " ").replace(/\s+([?!.,:;])/g, "$1").toLowerCase();
    }
    async function geminiCall({ apiKey, model = "gemini-2.5-flash-lite-preview-09-2025", prompt }) {
      if (!apiKey) throw new Error("Missing GEMINI_API_KEY");
      const { GoogleGenerativeAI } = await import("@google/generative-ai");
      const genAI = new GoogleGenerativeAI(apiKey);
      const m = genAI.getGenerativeModel({ model });
      const result = await m.generateContent({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.6, topK: 32, topP: 0.9, maxOutputTokens: 1024 }
      });
      return (result?.response?.text?.() || "").trim();
    }
    async function openaiCall({ apiKey, model = "gpt-4o-mini", prompt }) {
      if (!apiKey) throw new Error("Missing OPENAI_API_KEY");
      const resp = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: "You are a quiz line generator. Follow rules exactly." },
            { role: "user", content: prompt }
          ],
          temperature: 0.6,
          max_tokens: 800
        })
      });
      if (!resp.ok) {
        let detail = await resp.text().catch(() => String(resp.status));
        try {
          detail = JSON.parse(detail);
        } catch {
        }
        const err = new Error(`OpenAI HTTP ${resp.status}`);
        err.status = resp.status;
        err.details = detail;
        throw err;
      }
      const data = await resp.json();
      return (data?.choices?.[0]?.message?.content || "").trim();
    }
    function toTitleCase(str) {
      if (!str) return "";
      return String(str).toLowerCase().replace(/(^|[\s_-])([a-z])/g, (_, p1, p2) => `${p1}${p2.toUpperCase()}`).trim();
    }
    function echoGenerate({ topic, count, types, kind }) {
      const out = [];
      const t = topic || "General knowledge";
      const T = toTitleCase(t);
      const allowed = Array.isArray(types) && types.length ? types.map((x) => x.toUpperCase()).filter((x) => /^(MC|TF|YN|MT)$/.test(x)) : ["MC", "TF", "YN", "MT"];
      const pickType = (i) => allowed[i % allowed.length];
      if (kind === "structured") {
        const questions = [];
        for (let i = 0; i < count; i++) {
          const tt = pickType(i);
          if (tt === "MC") {
            questions.push({
              type: "MC",
              prompt: `About ${T} \u2014 Sample Q ${i + 1}?`,
              options: ["Option A", "Option B", "Option C", "Option D"],
              correct: ["A"]
            });
          } else if (tt === "TF") {
            questions.push({ type: "TF", prompt: `About ${T} \u2014 Sample Q ${i + 1}.`, correct: true });
          } else if (tt === "YN") {
            questions.push({ type: "YN", prompt: `About ${T} \u2014 Sample Q ${i + 1}?`, correct: true });
          } else {
            questions.push({
              type: "MT",
              prompt: `About ${T} \u2014 Match ${i + 1}.`,
              left: ["Term 1", "Term 2"],
              right: ["Definition A", "Definition B"],
              matches: [[1, "A"], [2, "B"]]
            });
          }
        }
        return JSON.stringify({ title: `${T} Quiz`, topic: T, questions }, null, 2);
      }
      for (let i = 0; i < count; i++) {
        const tt = pickType(i);
        if (tt === "MC") out.push(`MC|About ${T} \u2014 Sample Q ${i + 1}?|A) Option A;B) Option B;C) Option C;D) Option D|A`);
        else if (tt === "TF") out.push(`TF|About ${T} \u2014 Sample Q ${i + 1}.|T`);
        else if (tt === "YN") out.push(`YN|About ${T} \u2014 Sample Q ${i + 1}?|Y`);
        else out.push(`MT|About ${T} \u2014 Match ${i + 1}.|1) Term 1;2) Term 2|A) Definition A;B) Definition B|1-A,2-B`);
      }
      return out.join("\n");
    }
    async function callProvider2({ provider, model, topic, count, types, difficulty, env, prompt, kind = "legacy" }) {
      const selected = (provider || (env.AI_PROVIDER || "gemini")).toLowerCase();
      const normalizedCount = Math.max(1, Math.min(50, parseInt(count || 10, 10)));
      const resolvedPrompt = prompt || buildPrompt(topic, normalizedCount, types, difficulty);
      try {
        if (selected === "gemini") {
          const resolvedModel = model || env.GEMINI_MODEL || "gemini-2.5-flash-lite-preview-09-2025";
          const text = await geminiCall({ apiKey: env.GEMINI_API_KEY, model: resolvedModel, prompt: resolvedPrompt });
          return { provider: "gemini", model: resolvedModel, text };
        }
        if (selected === "openai") {
          const resolvedModel = model || env.OPENAI_MODEL || "gpt-4o-mini";
          const text = await openaiCall({ apiKey: env.OPENAI_API_KEY, model: resolvedModel, prompt: resolvedPrompt });
          return { provider: "openai", model: resolvedModel, text };
        }
        if (selected === "echo") {
          const text = echoGenerate({ topic, count: normalizedCount, types, difficulty, kind });
          return { provider: "echo", model: "stub", text };
        }
        throw new Error(`Unknown provider: ${provider}`);
      } catch (err) {
        const e = new Error(String(err && err.message || err));
        e.status = err && err.status;
        e.details = err && err.details;
        throw e;
      }
    }
    async function generateLines2({ provider, model, topic, count, types, difficulty, env }) {
      const n = Math.max(1, Math.min(50, parseInt(count || 10, 10)));
      const prompt = buildPrompt(topic, n, types, difficulty);
      const { provider: usedProvider, model: usedModel, text } = await callProvider2({ provider, model, topic, count: n, types, difficulty, env, prompt, kind: "legacy" });
      const { title, lines } = normalizeLegacyLines(text, n);
      return { provider: usedProvider, model: usedModel, title, lines };
    }
    async function generateInBatches2({ provider, model, topic, count, types, difficulty, env = process.env, batchSize, maxPasses }) {
      const targetRaw = count == null ? 10 : count;
      let target = parseInt(targetRaw, 10);
      if (!Number.isFinite(target)) target = 10;
      target = Math.max(1, Math.min(100, target));
      let batch = parseInt(batchSize, 10);
      if (!Number.isFinite(batch)) batch = Math.min(40, target);
      batch = Math.max(1, Math.min(50, batch));
      let passes = parseInt(maxPasses, 10);
      if (!Number.isFinite(passes) || passes < 1) {
        passes = Math.ceil(target / batch) + 2;
      }
      passes = Math.max(2, Math.min(12, passes));
      const seen = /* @__PURE__ */ new Set();
      const collected = [];
      let resolvedTitle = "";
      let resolvedProvider = "";
      let resolvedModel = "";
      for (let attempt = 0; attempt < passes && collected.length < target; attempt++) {
        const remaining = target - collected.length;
        const ask = Math.min(50, Math.max(batch, remaining));
        const { title, lines, provider: usedProvider, model: usedModel } = await generateLines2({ provider, model, topic, count: ask, types, difficulty, env });
        if (!resolvedTitle && title) resolvedTitle = title;
        if (usedProvider) resolvedProvider = usedProvider;
        if (usedModel) resolvedModel = usedModel;
        const chunkLines = splitNormalizedLines(lines);
        for (const line of chunkLines) {
          const key = stemKeyFromLine(line);
          if (!key || seen.has(key)) continue;
          seen.add(key);
          collected.push(line);
          if (collected.length >= target) break;
        }
      }
      return {
        provider: resolvedProvider || provider || "",
        model: resolvedModel || model || "",
        title: resolvedTitle,
        lines: collected.slice(0, target).join("\n")
      };
    }
    module2.exports = { generateLines: generateLines2, generateInBatches: generateInBatches2, callProvider: callProvider2, buildStructuredPrompt: buildStructuredPrompt2 };
  }
});

// netlify/functions/generate-quiz.js
var { generateLines, generateInBatches, callProvider, buildStructuredPrompt } = require_providers();
var { normalizeQuizV2, quizToLegacyLines } = require_normalizer();
function parseAllowedOrigins() {
  const raw = process.env.ALLOWED_ORIGINS || "";
  return raw.split(",").map((s) => s.trim()).filter(Boolean);
}
function getOrigin(headers) {
  const h = headers || {};
  return h.origin || h.Origin || "";
}
function makeCorsHeaders(origin) {
  const H = {
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (origin) H["Access-Control-Allow-Origin"] = origin;
  return H;
}
function reply(statusCode, body, origin) {
  const headers = makeCorsHeaders(origin);
  return {
    statusCode,
    headers,
    body: typeof body === "string" ? body : JSON.stringify(body)
  };
}
var RL = /* @__PURE__ */ new Map();
var DEFAULT_LIMIT = 60;
var DEFAULT_WINDOW_MS = 15 * 60 * 1e3;
function toPositiveInt(value, fallback) {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
var LIMIT = toPositiveInt(process.env.GENERATE_LIMIT, DEFAULT_LIMIT);
var WINDOW_MS = toPositiveInt(process.env.GENERATE_WINDOW_MS, DEFAULT_WINDOW_MS);
var CLIENT_MAX = Math.max(1, Math.min(100, toPositiveInt(process.env.GENERATE_CLIENT_MAX || process.env.CLIENT_MAX_QUESTIONS, 30)));
var CONFIGURED_MAX = Math.max(1, Math.min(100, toPositiveInt(process.env.GENERATE_MAX_COUNT, CLIENT_MAX)));
var MAX_COUNT = Math.min(CLIENT_MAX, CONFIGURED_MAX);
var BEARER_TOKEN = process.env.GENERATE_BEARER_TOKEN ? String(process.env.GENERATE_BEARER_TOKEN) : "";
function clientIp(event) {
  const h = event.headers || {};
  const xf = h["x-forwarded-for"] || h["X-Forwarded-For"] || "";
  const ip = (Array.isArray(xf) ? xf[0] : String(xf).split(",")[0]).trim() || h["client-ip"] || h["x-nf-client-connection-ip"] || "unknown";
  return String(ip);
}
function rateLimited(event) {
  if (!LIMIT) return false;
  const now = Date.now();
  const ip = clientIp(event);
  const arr = RL.get(ip) || [];
  const fresh = arr.filter((ts) => now - ts < WINDOW_MS);
  if (fresh.length >= LIMIT) return true;
  fresh.push(now);
  RL.set(ip, fresh);
  if (RL.size > 500) {
    for (const [k, list] of RL.entries()) {
      const keep = list.filter((ts) => now - ts < WINDOW_MS);
      if (keep.length) RL.set(k, keep);
      else RL.delete(k);
    }
  }
  return false;
}
function authorize(event) {
  if (!BEARER_TOKEN) return true;
  const h = event.headers || {};
  const raw = h.authorization || h.Authorization || "";
  if (!raw || typeof raw !== "string") return false;
  const trimmed = raw.trim();
  if (!trimmed.toLowerCase().startsWith("bearer ")) return false;
  const token = trimmed.slice(7).trim();
  return token === BEARER_TOKEN;
}
exports.handler = async (event) => {
  const allowedOrigins = parseAllowedOrigins();
  const origin = getOrigin(event.headers);
  const originAllowed = !origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin);
  if (event.httpMethod === "OPTIONS") {
    if (!originAllowed) return reply(403, { error: "Forbidden origin" }, "");
    return reply(204, "", origin || (allowedOrigins.length === 0 ? "*" : ""));
  }
  if (!originAllowed) return reply(403, { error: "Forbidden origin" }, "");
  const responseOrigin = origin || (allowedOrigins.length === 0 ? "*" : "");
  if (event.httpMethod !== "POST") return reply(405, { error: "Method Not Allowed" }, responseOrigin);
  if (!authorize(event)) {
    const res = reply(401, { error: "Unauthorized" }, responseOrigin);
    res.headers["WWW-Authenticate"] = "Bearer";
    return res;
  }
  if (rateLimited(event)) {
    const retry = Math.ceil(WINDOW_MS / 1e3);
    const res = reply(429, { error: "Rate limited" }, responseOrigin);
    res.headers["Retry-After"] = String(retry);
    return res;
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return reply(400, { error: "Invalid JSON" }, responseOrigin);
  }
  const topicRaw = (payload.topic == null ? "" : String(payload.topic)).trim();
  const topic = topicRaw || "General knowledge";
  let count = payload.count;
  if (count == null) {
    count = 10;
  }
  const parsedCount = parseInt(count, 10);
  if (!Number.isFinite(parsedCount)) {
    return reply(400, { error: `Invalid count: must be a number between 1 and ${MAX_COUNT}` }, responseOrigin);
  }
  count = Math.max(1, Math.min(MAX_COUNT, parsedCount));
  let types = void 0;
  if (payload.types !== void 0) {
    if (!Array.isArray(payload.types)) {
      return reply(400, { error: "Invalid types: must be an array of MC|TF|YN|MT" }, responseOrigin);
    }
    const filtered = payload.types.filter((t) => /^(MC|TF|YN|MT)$/i.test(String(t)));
    if (payload.types.length && filtered.length === 0) {
      return reply(400, { error: "Invalid types: use MC, TF, YN, MT" }, responseOrigin);
    }
    types = filtered;
  }
  const difficulty = payload.difficulty && String(payload.difficulty).toLowerCase() || void 0;
  const provider = String(payload.provider || process.env.AI_PROVIDER || "gemini");
  const model = String(payload.model || "");
  const responseMode = String(process.env.QUIZ_RESPONSE || "").toLowerCase();
  const useV2 = responseMode === "v2";
  const queryFormat = event.queryStringParameters && event.queryStringParameters.format || "";
  const headerFormat = event.headers && (event.headers["x-quiz-format"] || event.headers["X-Quiz-Format"]) || "";
  const requestedFormat = String(payload.format || headerFormat || queryFormat).toLowerCase();
  const wantsLegacyOnly = requestedFormat === "legacy-lines";
  const wantsStructured = useV2 && !wantsLegacyOnly && (requestedFormat === "quiz-json" || requestedFormat === "quiz-v2" || requestedFormat === "json");
  const structuredPrompt = wantsStructured ? buildStructuredPrompt(topic, count, types, difficulty) : null;
  function buildStructuredResponse({ quiz, provider: providerName, model: modelName, fallbackUsed = false, fallbackFrom, errorPrimary }) {
    const legacy = quizToLegacyLines(quiz, { count });
    const meta = {
      provider: providerName,
      model: modelName,
      fallbackUsed: !!fallbackUsed
    };
    if (fallbackUsed && fallbackFrom) meta.fallbackFrom = fallbackFrom;
    if (fallbackUsed && errorPrimary) meta.errorPrimary = errorPrimary;
    const response = {
      ...meta,
      title: legacy.title,
      lines: legacy.lines
    };
    if (!wantsLegacyOnly) {
      response.quiz = quiz;
    }
    return response;
  }
  function withTimeout(promise, ms) {
    return new Promise((resolve, reject) => {
      const id = setTimeout(() => reject(Object.assign(new Error("Upstream timeout"), { status: 504 })), ms);
      promise.then((v) => {
        clearTimeout(id);
        resolve(v);
      }, (e) => {
        clearTimeout(id);
        reject(e);
      });
    });
  }
  const TIMEOUT_MS = Math.max(8e3, Math.min(2e4, parseInt(process.env.GENERATE_TIMEOUT_MS || "15000", 10)));
  const corsHeaders = makeCorsHeaders(responseOrigin);
  try {
    if (wantsStructured) {
      const primary = await withTimeout(
        callProvider({ provider, model, topic, count, types, difficulty, env: process.env, prompt: structuredPrompt, kind: "structured" }),
        TIMEOUT_MS
      );
      const quiz = normalizeQuizV2(primary.text, { topic, count, types });
      const payloadBody = buildStructuredResponse({ quiz, provider: primary.provider, model: primary.model, fallbackUsed: false });
      return {
        statusCode: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        body: JSON.stringify(payloadBody)
      };
    }
    const generator = count > 50 ? generateInBatches : generateLines;
    const { title, lines, provider: usedProvider, model: usedModel } = await withTimeout(
      generator({ provider, model, topic, count, types, difficulty, env: process.env }),
      TIMEOUT_MS
    );
    return {
      statusCode: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      body: JSON.stringify({ title, lines, provider: usedProvider, model: usedModel, fallbackUsed: false })
    };
  } catch (err) {
    const msg = String(err && err.message || err || "Error");
    const is429 = msg.includes("429") || /quota|rate limit/i.test(msg) || err && err.status === 429;
    const isTimeout = err && (err.status === 504 || /timeout/i.test(msg));
    const primary = (provider || "").toLowerCase();
    const canFallbackToGemini = primary !== "gemini" && !!process.env.GEMINI_API_KEY;
    if (wantsStructured) {
      if (canFallbackToGemini && !isTimeout) {
        try {
          const fallback = await withTimeout(
            callProvider({ provider: "gemini", model: process.env.GEMINI_MODEL || "gemini-2.5-flash-lite-preview-09-2025", topic, count, types, difficulty, env: process.env, prompt: structuredPrompt, kind: "structured" }),
            TIMEOUT_MS
          );
          const fallbackLen = typeof fallback.text === "string" ? fallback.text.length : 0;
          console.warn("[quiz-v2]", { reason: "provider-fallback", len: fallbackLen });
          const quiz = normalizeQuizV2(fallback.text, { topic, count, types });
          const payloadBody = buildStructuredResponse({
            quiz,
            provider: fallback.provider,
            model: fallback.model,
            fallbackUsed: true,
            fallbackFrom: primary,
            errorPrimary: msg
          });
          return {
            statusCode: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            body: JSON.stringify(payloadBody)
          };
        } catch (fallbackErr) {
          console.warn("[quiz-v2]", { reason: "provider-fallback-failed", len: 0 });
          const fbMsg = String(fallbackErr && fallbackErr.message || fallbackErr || "Error");
          return {
            statusCode: isTimeout ? 504 : err && err.status || fallbackErr && fallbackErr.status || (is429 ? 429 : 502),
            headers: { ...corsHeaders, ...is429 ? { "Retry-After": "30" } : {}, ...isTimeout ? { "Retry-After": "15" } : {} },
            body: JSON.stringify({ error: "Generation failed", details: msg, fallback: { tried: "gemini", details: fbMsg } })
          };
        }
      }
      const statusFromError2 = err && err.status;
      let statusCode2 = isTimeout ? 504 : is429 ? 429 : statusFromError2 || 502;
      if (statusCode2 === 404) {
        statusCode2 = 502;
      }
      try {
        const generator = count > 50 ? generateInBatches : generateLines;
        const { title, lines, provider: usedProvider, model: usedModel } = await withTimeout(
          generator({ provider, model, topic, count, types, difficulty, env: process.env }),
          TIMEOUT_MS
        );
        console.warn("[quiz-v2]", { reason: "structured-fallback-legacy" });
        return {
          statusCode: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          body: JSON.stringify({ title, lines, provider: usedProvider, model: usedModel, fallbackUsed: false })
        };
      } catch (legacyErr) {
        const legacyMsg = String(legacyErr && legacyErr.message || legacyErr || "Error");
        return {
          statusCode: statusCode2,
          headers: { ...corsHeaders, ...is429 ? { "Retry-After": "30" } : {}, ...isTimeout ? { "Retry-After": "15" } : {} },
          body: JSON.stringify({ error: isTimeout ? "Generation timed out" : "Generation failed", details: legacyMsg, provider })
        };
      }
    }
    if (canFallbackToGemini && !isTimeout) {
      const generator = count > 50 ? generateInBatches : generateLines;
      try {
        const { title, lines, provider: usedProvider, model: usedModel } = await withTimeout(
          generator({ provider: "gemini", model: process.env.GEMINI_MODEL || "gemini-2.5-flash-lite-preview-09-2025", topic, count, types, difficulty, env: process.env }),
          TIMEOUT_MS
        );
        return {
          statusCode: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          body: JSON.stringify({ title, lines, provider: usedProvider, model: usedModel, fallbackUsed: true, fallbackFrom: primary, errorPrimary: msg })
        };
      } catch (fallbackErr) {
        const fbMsg = String(fallbackErr && fallbackErr.message || fallbackErr || "Error");
        return {
          statusCode: isTimeout ? 504 : err && err.status || fallbackErr && fallbackErr.status || (is429 ? 429 : 502),
          headers: { ...corsHeaders, ...is429 ? { "Retry-After": "30" } : {}, ...isTimeout ? { "Retry-After": "15" } : {} },
          body: JSON.stringify({ error: "Generation failed", details: msg, fallback: { tried: "gemini", details: fbMsg } })
        };
      }
    }
    const statusFromError = err && err.status;
    let statusCode = isTimeout ? 504 : is429 ? 429 : statusFromError || 502;
    if (statusCode === 404) {
      statusCode = 502;
    }
    return {
      statusCode,
      headers: { ...corsHeaders, ...is429 ? { "Retry-After": "30" } : {}, ...isTimeout ? { "Retry-After": "15" } : {} },
      body: JSON.stringify({ error: isTimeout ? "Generation timed out" : "Generation failed", details: msg, provider })
    };
  }
};
